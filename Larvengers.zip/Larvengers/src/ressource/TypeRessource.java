package ressource;

public enum TypeRessource {
	PICKLE,
	COCKTAIL,
	POOP
}
