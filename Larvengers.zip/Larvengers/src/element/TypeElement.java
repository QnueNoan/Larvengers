package element;

public enum TypeElement {
	LARVA,
	COCOON,
	BUTTERFLY,
	MOSKITO,
	RESSOURCE,
	PICKLE,
	COCKTAIL,
	POOP
}
